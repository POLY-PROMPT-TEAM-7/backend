#!/bin/bash
echo "this should error"
